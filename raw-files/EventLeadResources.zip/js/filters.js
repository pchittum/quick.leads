//currently no filters, but investigating ways to leverage this angular feature in lieu of my 
//hacky cobbled together semi-Angular approach that got me to where I am now!